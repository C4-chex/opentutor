"""add intervention_outcomes table

Revision ID: b8dc85d1df33
Revises: 0023_content_schema_sync
Create Date: 2026-03-12 02:08:17.659038

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = 'b8dc85d1df33'
down_revision: Union[str, None] = '0023_content_schema_sync'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    pass


def downgrade() -> None:
    pass
