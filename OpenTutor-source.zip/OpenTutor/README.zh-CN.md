# OpenTutor · 本地学习定制版

基于 [zijinz456/OpenTutor](https://github.com/zijinz456/OpenTutor) 的个人学习项目，面向导入资料后的小步教学、理解检查和实操练习。

[English](README.md) · **中文**

## 当前功能

- 导入 PDF、Word、PPT，以及网页或 GitHub 教程；GitHub 内容可预览、筛选后导入。
- 依据原材料进行苏格拉底式引导、费曼解释、独立练习与迁移检查。
- 答错时给一个小提示，原题可重试，默认不直接展示答案。
- 首页可调“慢一点 / 按画像调整 / 快一点”，结合学习基础、目标与实际作答安排节奏。
- 学习画像、课程、进度和反馈保存在本地；设置页可修改画像。
- 用户自备模型 API。连接外部模型时，相应教学材料和作答会发送给所配置的服务商。

当前主要验证 Windows 原生运行。编程题通过 AI 静态审阅，不在应用内编译或执行代码。实验图谱等上游功能默认不额外开启。

## 从源码运行：Windows

已验证的环境：Python 3.12、Node.js 24。先安装这两个运行环境和 Git。以下命令在克隆或解压后的项目根目录执行。

首次安装：

```powershell
Copy-Item .env.example apps/api/.env
py -3.12 -m venv apps/api/.venv
apps/api/.venv/Scripts/python.exe -m pip install -r scripts/requirements-windows.lock
npm.cmd --prefix apps/web ci
```

在 `apps/api/.env` 中填写自己的模型配置，或启动后到设置页填写。示例文件不含密钥，切勿将填好的 `.env` 上传。

打开第一个终端启动后端：

```powershell
Set-Location apps/api
.venv/Scripts/python.exe -X utf8 -m uvicorn main:app --host 127.0.0.1 --port 8000
```

在项目根目录打开第二个终端，构建并启动网页：

```powershell
$env:NEXT_PUBLIC_API_URL = "http://127.0.0.1:8000/api"
npm.cmd --prefix apps/web run build
npm.cmd --prefix apps/web run start -- --hostname 127.0.0.1 --port 3001
```

访问 [http://localhost:3001](http://localhost:3001)。源码未变化时，后续使用可以跳过安装和构建。首次进入需要设置学习画像。

上述手动启动方式默认将 SQLite 数据保存在当前用户的 `.opentutor` 目录，上传文件保存在 `apps/api/uploads/`。已配置 EXE 的本机使用独立的 `native-data/`，两种启动方式的数据位置见[原生运行说明](docs/guides/windows-native.zh-CN.md)。

## 已配置的本地 EXE

已有原生环境时，可双击 `OpenTutor.exe` 或 `Start-OpenTutor.cmd`。EXE 只负责启动、停止和备份，本体可由 `scripts/build-native-launcher.ps1` 构建；源码仓库不包含本机的运行环境、密钥、数据库或预编译 EXE。新克隆的仓库请先使用上面的源码启动方法。

## 文档

- [Windows 原生运行、EXE 与备份](docs/guides/windows-native.zh-CN.md)
- [GitHub 教程导入](docs/guides/github-import.zh-CN.md)
- [苏格拉底与费曼教学](docs/guides/guided-learning.zh-CN.md)
- [小提示与轻量反馈](docs/guides/grading.zh-CN.md)
- [学习画像与速度](docs/guides/learning-pace.zh-CN.md)
- [教学设计与后续范围](docs/guides/learning-design.zh-CN.md)
- [准备上传 GitHub](docs/publishing.zh-CN.md)

`apps/` 是应用源码，`tests/` 是测试，`scripts/` 包含启动、备份与检查工具。Docker 与云部署文件来自上游，保留供参考；本定制版以 Windows 原生路径为主要验证方式。

## 许可证与来源

沿用上游 [MIT License](LICENSE)，保留原作者版权声明。原项目与本定制版的功能、运行方式可能不同；具体以本仓库文档为准。
