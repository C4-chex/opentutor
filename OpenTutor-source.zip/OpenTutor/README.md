# OpenTutor · Local Learning Fork

A personal learning fork of [zijinz456/OpenTutor](https://github.com/zijinz456/OpenTutor), focused on learning from imported materials.

**English** · [中文与安装步骤](README.zh-CN.md)

## Features

- Import documents, webpages and selected GitHub tutorial files.
- Source-grounded Socratic guidance, Feynman explanations, independent practice and transfer checks.
- Small hints after mistakes, with retries on the original question and no automatic answer reveal.
- A home-page learning pace control, informed by the learner's background, goals and actual answers.
- Local course, profile, progress and feedback storage.
- Bring your own model API. Relevant teaching materials and answers are sent to the configured provider when an external model is used.

The main validated setup is Windows with Python 3.12 and Node.js 24. Coding exercises use static AI review; student code is not compiled or executed by this application.

## Run from source

Install Python 3.12, Node.js 24 and Git, then run these commands from the project root in PowerShell:

```powershell
Copy-Item .env.example apps/api/.env
py -3.12 -m venv apps/api/.venv
apps/api/.venv/Scripts/python.exe -m pip install -r scripts/requirements-windows.lock
npm.cmd --prefix apps/web ci
```

Configure your provider in `apps/api/.env` or in the app's settings. The example contains no API key. Never commit your actual configuration.

Start the API in one terminal:

```powershell
Set-Location apps/api
.venv/Scripts/python.exe -X utf8 -m uvicorn main:app --host 127.0.0.1 --port 8000
```

In a second terminal at the project root:

```powershell
$env:NEXT_PUBLIC_API_URL = "http://127.0.0.1:8000/api"
npm.cmd --prefix apps/web run build
npm.cmd --prefix apps/web run start -- --hostname 127.0.0.1 --port 3001
```

Open [http://localhost:3001](http://localhost:3001) and complete the learner profile. Installation and rebuilding are unnecessary for subsequent runs unless dependencies or source files change.

This manual setup defaults to SQLite in the current user's `.opentutor` folder and uploads in `apps/api/uploads/`. An existing native-launcher setup uses its separate `native-data/` configuration.

## Native launcher and documentation

`OpenTutor.exe` is a launcher, not a self-contained distribution. Its C# source and build script are included; the generated EXE, Python/Node runtimes, installed dependencies and personal data are excluded from Git. A fresh clone should use the source setup above.

- [Windows native setup and backups](docs/guides/windows-native.zh-CN.md)
- [GitHub tutorial import](docs/guides/github-import.zh-CN.md)
- [Guided teaching](docs/guides/guided-learning.zh-CN.md)
- [Hint-first feedback](docs/guides/grading.zh-CN.md)
- [Learning pace and profile](docs/guides/learning-pace.zh-CN.md)
- [Publishing a clean source tree](docs/publishing.zh-CN.md)

Application source is under `apps/`, tests under `tests/`, and local tooling under `scripts/`. Upstream Docker and cloud deployment files are retained for reference; Windows native execution is the main validated route for this fork.

## License and attribution

[MIT License](LICENSE). Original project and copyright: [zijinz456/OpenTutor](https://github.com/zijinz456/OpenTutor). Original notices are preserved. Features and setup differ from upstream; refer to this fork's documentation.
